//
//  PaymentSDK.h
//  PaymentSDK
//
//  Created by Sachin Thakur on 28/08/17.
//  Copyright © 2017 Paytm. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PaymentSDK.
FOUNDATION_EXPORT double PaymentSDKVersionNumber;

//! Project version string for PaymentSDK.
FOUNDATION_EXPORT const unsigned char PaymentSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PaymentSDK/PublicHeader.h>


